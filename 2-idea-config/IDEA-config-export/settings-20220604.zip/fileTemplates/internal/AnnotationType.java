#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
* @author DeltaV235
* @version 1.0
*/
public @interface ${NAME} {
}
